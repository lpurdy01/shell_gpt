from setuptools import setup, find_packages

# pylint: disable=consider-using-with
setup(
    name="shell_gpt",
    version="0.8.8.2",
    packages=find_packages(),
    install_requires=[
        "typer~=0.7.0",
        "requests~=2.28.2",
        "rich==13.3.1",
        "distro~=1.8.0",
    ],
    extras_require={
        ':sys_platform == "win32"': ["pyreadline3"]
    },
    entry_points={
        "console_scripts": ["sgpt = sgpt:cli"],
    },
    author="Farkhod Sadykov",
    author_email="farkhod@sadykov.dev",
    description=(
        "A command-line productivity tool powered by ChatGPT, "
        "will help you accomplish your tasks faster and more efficiently."
        "0.8.8.2, updated with -c -sc -lc, default as gpt itself, not a command line tool -- Martlet"
    ),
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    url="https://github.com/MartletH/shell_gpt",
)
